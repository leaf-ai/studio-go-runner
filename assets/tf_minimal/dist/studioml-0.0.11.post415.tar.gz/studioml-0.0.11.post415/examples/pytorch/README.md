# PyTorch Examples for Studio

General dependency:

```
pip install torch torchvision
```

## MNIST

Straightforward example for MNIST dataset, taken from `https://github.com/pytorch/examples/tree/master/mnist`:

```
studio run mnist.py
```

