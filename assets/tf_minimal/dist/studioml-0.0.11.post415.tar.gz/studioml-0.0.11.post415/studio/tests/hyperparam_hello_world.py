import sys

learning_rate = 0.3
print(learning_rate)

sys.stdout.flush()
